#include <iostream>
#include <math.h>
#include <stdio.h>
#include <string.h>
using namespace std;
// Program subgrupa 1331A, FSA


// BUDECI ANA-MARIA
// Rezolvari din capitolul 1: PROBLEME SIMPLE DE PROGRAMARE
//      1.1. Rezolvare completa pentru ecuatia de gradul al doilea
//      1.2. Inmultirea a doua matrice
//      1.3. Verificare numar prim
//      1.4. Trecerea unui numar din baza 10 in baza b=2,...,9
// Rezolvari din capitolul 2: ALGORITMI DE SORTARE
//      2.1. Sortare prin metoda bulelor (bubble sort)
//      2.2. Sortare prin selectie (selection sort)
//      2.3. Sortare prin numarare (counting sort)
//      2.4. Sortare prin contopore (merge sort)
//      2.5. Sortare prin interclasare (quick sort)
//      2.6. Sortare prin insertie (insertion sort)
//      2.7. Sortare prin intertie din pas in pas (shell sort)
//      2.8. Sortarea Radix  (radix sort)
//      2.9. Cautarea unui element prin cautarea binara
//      2.10. Cautarea unui element prin cautarea secventiala
// Rezolvari capitoul 3: LISTE, CORZI, STIVE
//      3.1. Operatii cu liste simplu inlantuite: creare, parcurgere, agaugare, stergere, modificare // rezolvat
//      3.2. Operatii cu liste dublu inlantuite: creare, parcurgere, agaugare, stergere, modificare // rezolvat
//      3.3. Operatii cu stive: creare, parcurgere, adaugare, stergere // rezolvat
//      3.4. Operatii cu corzi: creare, parcurgere, adaugare, stergere // rezolvat
//      3.5. Operatii cu crearea unei liste de numere intregi ordonata
//      3.6. Interclasarea a doua liste ordonate
//      3.7. Adunarea polinoamelor // rezolvat
//      3.8. Inmultirea polinoamelor
//      3.9. Verificare corectitudine paranteze in expresie aritmetica // rezolvat
// Rezolvari capitolul 4: GRAFURI. APLICATII
//      4.1. Reprezentare matrice de adiacenta <=> lista de noduri
//      4.2. Reprezentare matrice de adiacenta <=> lista de muchii
//      4.3. Reprezentare lista de noduri <=> lista de muchii
//      4.4. Moduri de parcurgere grafuri: in adancime si in latime
//      4.5. Verificare existenta drum intre oricare doua noduri


// variabilele globale

// structura pentru lista simplu inlantuita
typedef struct numar
{
    int v;
    numar *urm;
}numar;
// structura pentru lista dublu inlantuita
typedef struct numar2
{
    int v;
    numar2 *urm;
    numar2 *prec;
}numar2;
typedef struct lista2
{
    numar2 *prim;
    numar2 *ultim;
}lista2;
typedef struct punct
{
    float x;
    punct *urm;
}punct;
// structura pentru monom in polinom
typedef struct monom
{
    float coef;
    int grad;
    monom *urm;
}monom;


// functiile utilizatorului
void rezolva_ec2(float a, float b, float c)
{
    // rezolva ecuatia
    float d, x1, x2, pr, pi;
    if(a==0) // ecuatia este de gradul 1(bx+c=0)
    {
        if(b==0) // ecuatia se reduce la c=0;
        {
            if(c==0) //ecuatia se reduce la 0=0;
                cout<<"ecuatia are o infinitate de solutii"<<endl;
            else
                cout<<"ecuatia nu are solutie"<<endl;
        }
        else
        cout<<"solutie este unica x=" <<-c/b<<endl;
    }
    else // ecuatia este de gradul al 2-lea;
    {
        d=b*b-4*a*c;
        if(d>0) // radacini reale distincte;
        {
            x1=(-b+sqrt(d))/(2*a);
            x2=(-b-sqrt(d))/(2*a);
            cout<<"x1="<<x1<<endl;
            cout<<"x2="<<x2<<endl;
        }
        else // d<=0;
        {
            if(d==0)// are 2 radacini reale egale;
            {
                x1=-b/(2*a);
                cout<<"x1=x2"<<x1<<endl;
            }
            else // d<0;
            {
                // ecuatia are radacini complexe;
                pr=-b/(2*a);
                pi=sqrt(-d)/(2*a);
                cout<<"x1="<<pr<<"+i*"<<pi<<endl;
                cout<<"x2="<<pr<<"-i*"<<pi<<endl;
            }
        }
    }
}
void inmultirea_matricelor(int r1, int c1, int r2, int c2)
{
    int a[10][10], b[10][10], mult[10][10], i, j, k;
    while(c1!=r2)
    {
        cout<<"Eroare! Coloanele din prima matrice nu sunt egale cu randurile din a doua matrice.";
        cout<<"Introduceti randurile si coloanele primei matrice: ";
        cout<<"r1= ";
        cin>>r1;
        cout<<endl<<"c1= ";
        cin>>c1;
        cout<<endl<<"Introduceti randurile si coloanele celei de-a doua matrice: ";
        cout<<"r2= ";
        cin>>r2;
        cout<<endl<<"c2= ";
        cin>>c2;
        cout<<endl;
    }
    // scrierea elementelor matricei 1
    cout<<endl<<"Introduceti elementele matricei 1:"<<endl;
    for(i=0; i<r1; i++)
        for(j=0; j<c1; j++)
        {
            cout<<"Introduceti elementul a"<<i+1<<j+1<<" : ";
            cin>>a[i][j];
        }
    // scrierea elementelor matricei 2
    cout<<endl<<"Introduceti elementele matricei 2:"<<endl;
    for(i=0; i<r2; i++)
        for(j=0; j<c2; j++)
        {
            cout<<"Introduceti elementul b"<<i+1<<j+1<<" : ";
            cin>>b[i][j];
        }
    // initializarea elementelor matricei mult cu 0
    for(i=0; i<r1; i++)
        for(j=0; j<c2; j++)
        {
            mult[i][j]=0;
        }
    // inmultirea celor 2 matrice si scrierea in matricea mult
    for(i=0; i<r1; i++)
        for(j=0; j<c2; j++)
            for(k=0; k<c1; k++)
            {
                mult[i][j]+=a[i][k]*b[k][j];
            }
    // afisarea matricei mult
    cout<<endl<<"Matricea rezultata:"<<endl;
    for(i=0; i<r1; i++)
    for(j=0; j<c2; j++)
    {
        cout<<" "<<mult[i][j];
        if(j==c2-1)
            cout<<endl;
    }
}
void numar_prim(int n)
{
    int i;
    bool prim=true;
    // 0 si 1 nu sunt numere prime
    if(n==0 || n==1)
    {
        prim=false;
    }
    else
    {
        for(i=2; i<=n/2; i++)
        {
            if(n%i==0)
            {
                prim=false;
                break;
            }
        }
    }
    if(prim)
        cout<<n<<" este un numar prim"<<endl;
    else
        cout<<n<<" nu este un numar prim"<<endl;
}
void schimbare_baza(int n, int i)
{
    int x=0, rest=0, p=1;
    while(n!=0)
    {
        cout<<n<<" : "<<i<<" = ";
        rest=n%i;
        n=n/i;
        cout<<n<<" rest "<<rest<<endl;
        x=x+rest*p;
        p=p*10;
    }
}
void bubble_sort(int m, float a[20])
{
    int ind, i, b;
    float aux;
    b=0; // numara parcurgerile sirului
    do
    {
        b++;
        ind=1; // nu s-a facut inca nicio interschimbare intre elementele sirului
        for(i=0; i<=m-2; i++)
        {
            if(a[i] > a[i+1])
            {
                aux=a[i];
                a[i]=a[i+1];
                a[i+1]=aux;
                ind=0; // s-a facut o interschimbare
            }
        }
        cout<<"Dupa parcurgerea "<<b<<"sirul este:"<<endl;
        for(i=0; i<=m-1; i++)
            cout<<a[i]<<' ';
        cout<<endl;
        }while(ind==0);
    cout<<endl<<"Sirul ordonat dupa "<<b<<"parcugeri, este:"<<endl;
    for(i=0; i<=m-1; i++)
        cout<<a[i]<<' ';
    cout<<endl;
}
void selection_sort(int n, float x[20])
{
    int i, j, poz;
    float minim, aux;
    for(i=0; i<=n-2; i++)
    {
        // alege in variabila minim cea mai mica valoare dintre x[i],...,x[n-1]
        // retine pozitia minimului din subsirul x[i],...,x[n-1] in variabila poz
        minim=x[i];
        poz=i;
        for(j=i+1; j<=n-1; j++)
        {
            if(minim>x[j])
            {
                minim=x[j];
                poz=j;
            }
        }
        // daca i!=poz, atunci plaseaza pe pozitia i valoarea minima din subsirul x[i],...,x[n-1] schimband x[i] cu x[poz]
        if(i!=poz)
        {
            aux=x[i];
            x[i]=x[poz];
            x[poz]=aux;
        }
        cout<<endl<<"Pentru i= "<<i<<" se obtine: "<<endl;
        for(j=0; j<=n-1; j++)
            cout<<x[j]<<" ";
        cout<<endl;
    }
    cout<<"Sirul ordonat este: ";
    for(i=0; i<=n-1; i++)
            cout<<x[i]<<" ";
    cout<<endl;
}
void counting_sort(int n, int x[20])
{
    // dimensiunea numarului trebuie sa fie cel puțin (max+1)
    // noi nu putem atribui declararea acestuia ca numarare int (max+1) in C ++, deoarece nu accepta alocarea dinamica a memoriei
    // dimensiunea sa este furnizata static
    int y[10];
    int z[10];
    int maxim=x[0];
    int i;
    // gasiti cel mai mare element al sirului
    for(i=1; i<n; i++)
    {
        if(x[i]>maxim)
        maxim=x[i];
    }
    // initializarea elementelor sirul z cu 0
    for(i=0; i<=maxim; i++)
    {
        z[i]=0;
    }
    // stocarea fiecarui element
    for(i=0; i<n; i++)
    {
        z[x[i]]++;
    }
    // stocarea numarul cumulativ al fiecarui sir
    for(i=1; i<=maxim; i++)
    {
        z[i]=z[i]+z[i-1];
    }
    // cautarea fiecarui element al sirului original in sirul de numarare si plasarea elementelor in sirul de iesire
    for(i=n-1; i>=0; i--)
    {
            y[z[x[i]]-1]=x[i];
            z[x[i]]--;
    }
    // copierea elementelor sortate in sirul original
    for(i=0; i<n; i++)
    {
            x[i]=y[i];
    }
}
void merge_sort(int arr[], int p, int q, int r)
{
    // crearea L<-A[p..q] si M<-A[q+1..r]
    int n1=q-p+1;
    int n2=r-q;
    int L[n1], M[n2];
    for (int i=0; i<n1; i++)
        L[i]=arr[p+i];
    for(int j=0; j<n2; j++)
        M[j]=arr[q+1+j];
    // mentinem indicele curent al sub-tablourilor si al sirului principal
    int i, j, k;
    i=0;
    j=0;
    k=p;
    // pana cand ajungem la fiecare capat al lui L sau M, alegem mai mare dintre elementele L si M si le plasam in pozitia corecta la A[p..r]
    while(i<n1 && j<n2)
    {
        if(L[i]<=M[j])
        {
            arr[k]=L[i];
            i++;
        }
        else
        {
            arr[k]=M[j];
            j++;
        }
        k++;
    }
    // cand ramanem fara elemente in L sau M, ridicam elementele ramase si le introducem in A[p..r]
    while(i<n1)
    {
        arr[k]=L[i];
        i++;
        k++;
    }
    while(j<n2)
    {
        arr[k]=M[j];
        j++;
        k++;
    }
}
// impartim sirul in doua subsiruri, sortandu-le si imbinatindu-le
void mergeSort(int arr[], int l, int r)
{
    if(l<r)
    {
        // m este punctul unde sirul se divide in 2 subsiruri
        int m=l+(r-l)/2;
        mergeSort(arr,l,m);
        mergeSort(arr,m+1,r);
        // imbinarea subsirurilor sortati
        merge_sort(arr,l,m,r);
    }
}
// functia de afisare a sirului
void afisare(int n, int x[20])
{
    int i;
    for(i=0; i<n; i++)
        cout<<x[i]<<" ";
    cout<<endl;
}
// functia de a schimba pozitia elementelor
void inversare(int *a, int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
// functia de partitionare a sirului pe baza elementului pivot
int partitie(int arr[], int low, int high)
{
    // selectarea elementului pivoit
    int pivot=arr[high];
    int i=(low-1);
    // punem elementele mai mici decat pivotul in stanga și mai mare decat pivotul in dreapta
    for(int j=low; j<high; j++)
    {
        if(arr[j]<=pivot)
        {
            i++;
            inversare(&arr[i], &arr[j]);
        }
    }
    inversare(&arr[i+1],&arr[high]);
    return(i+1);
}
void quickSort(int arr[], int low, int high)
{
    if(low<high)
    {
        // selectam pozitia pivotului si punem toate elementele mai mici decat pivotul la stanga si mai mari decat pivotul la dreapta
        int pi=partitie(arr,low,high);
        // sortam elementele din stanga pivotului
        quickSort(arr, low, pi - 1);
        // sortam elementele din dreeapta pivotului
        quickSort(arr, pi + 1, high);
    }
}
void insertionSort(int arr[], int n)
{
    int i, j, k;
    for(i=1; i<n; i++)
    {
        k=arr[i];
        j=i-1;
        // comparam cheia cu fiecare element din stanga acestuia pana cand se gaseste un element mai mic decat este
        // pentru ordinea descrescatoare, schimbam k<sirul[j] la k>sirul[j]
        while(k<arr[j] && j>=0)
        {
            arr[j+1]=arr[j];
            --j;
        }
        arr[j+1]=k;
    }
}
void shellSort(int arr[], int n)
{
    int i, j, k=0;
    // rearanjam elementele la fiecare interval n/2, n/4, n/8,...,1  intervale
    for(i=n/2; i>0; i/=2)
    {
        for(j=i; j<n; j+=1)
        {
            k=arr[j];
            int z;
            for(z=j; z>=i && arr[z-i]>k; z-=i)
            {
                arr[z]=arr[z-i];
            }
            arr[z]=k;
        }
    }
}
// functie pentru a obtine cel mai mare element dintr-un sir
int obtine_maxim(int arr[], int n)
{
    int maxim=arr[0], i;
    for(i=1; i<n; i++)
        if(arr[i]>maxim)
            maxim=arr[i];
    return maxim;
}
void countingSort(int arr[], int n, int b)
{
    const int maxim=10;
    int output[n];
    int a[maxim];
    int i;
    for(i=0; i<maxim; i++)
        a[i]=0;
    // calculam numarul de elemente
    for(i=0; i<n; i++)
        a[(arr[i]/b)%10]++;
    // calculam numarul cumulativ
    for(i=1; i<maxim; i++)
        a[i]+=a[i-1];
    // plasam elementele in ordine sortata
    for(i=n-1; i>=0; i--)
    {
        output[a[(arr[i]/b)%10]-1]=arr[i];
        a[(arr[i]/b)%10]--;
    }
    for(i=0; i<n; i++)
        arr[i]=output[i];
}
// functia principala pentru implementarea sortarii radix
void radixsort(int arr[], int n)
{
    // obținem elementul maxim
    int maxim=obtine_maxim(arr,n);
    int i;
    // aplicam sortare de numarare pentru a sorta elemente pe baza valorii locului
    for(i= 1; maxim/i>0; i*=10)
        countingSort(arr,n,i);
}
int cautarea_binara(int arr[], int d, int low, int high)
{
    int mid;
	// repetam pana cand indicatoarele low si high se intalnesc
    while(low<=high)
    {
        mid=low+(high-low)/2;
        if(arr[mid]==d)
            return mid;
        if(arr[mid]<d)
            low=mid+1;
        else
            high=mid-1;
    }
    return -1;
}
int cautarea_secventiala(int arr[], int n, int d)
{
    int i=1;
    while(i<=n && arr[i]!=d)
        i++;
    if(i<=n)
        return 1;
    else
        return 0;
}
// functii pentru liste simplu inlantuite
numar *creare_lista()
{
    numar *cap, *u, *p;
    int x;
    char a;
    //creeaza capatul de lista
    cap=new numar;
    cout<<"Valoarea cap lista x=";
    cin>>x;
    cap->v=x;
    cap->urm=NULL;
    // u=ultimul element din lista, dupa care le adaugam pe urmatoarele
    u=cap; // initializare u
    do
    {
        cout<<"Adauga elemente in lista [D/N]?";
        cin>>a;
        if((a=='d') || (a=='D'))
        {
            p=new numar;
            cout<<"valoare de adaugat x=";
            cin>>x;
            p->v=x;
            p->urm=NULL;
            u->urm=p;
            u=p;
        }
    }while((a=='d') || (a=='D'));
    return cap;
}
void parcurgere_lista(numar *cap)
{
    numar *p;
    if(cap==NULL)
        cout<<"Lista este vida!"<<endl;
    else
    {
        p=cap;
        while(p!=NULL)
        {
            cout<<p->v<<" ";
            p=p->urm;
        }
    }
}
numar *stergere(numar *cap, int s)
{
    numar *p, *r;
    int c=0; // numara de cate ori apare elementul de sters
    while(cap->v==s)
    {
        c++;
        if(cap->urm!=NULL)
            cap=cap->urm;
        else
        {
            cap=cap->urm;
            break;
        }
    }
    p=cap->urm;
    r=cap; // r este precedentui lui p
    while(p!=NULL)
    {
        if(p->v==s)
        {
            c++;
            r->urm=p->urm;
            p=p->urm;
        }
        else
        {
            r=p;
            p=p->urm;
        }
    }
    cout<<"Elementul de sters "<<s<<" a aparut de "<<c<<" ori."<<endl;
    return cap;
}
numar *adaugare_in_lista(numar *cap, int xa)
{
    numar *p, *c; // variabila curenta
    int op=1;
    int a;
    cout<<"Element de adaugat xa= "<<xa<<endl;
    do
    {
        cout<<endl;
        cout<<"1. Adauga xa la inceput "<<endl;
        cout<<"2. Adauga xa dupa un element din lista"<<endl;
        cout<<"3. Adauga xa la sfarsit"<<endl;
        cout<<"0. A incheiat adaugarea"<<endl;
        cout<<"Alege optiune op_liste= ";
        cin>>op;
        switch (op)
        {
            case 1: // adaugare la inceput
                p=new numar;
                p->v=xa;
                p->urm=cap;
                cap=p;
                cout<<"Lista dupa adaugare la inceput este: ";
                parcurgere_lista(cap);
                break;
            case 2: // adaugare dupa elementdin lista
                cout<<"Adauga dupa a= ";
                cin>>a;
                c=cap;
                while(c!=NULL)
                {
                    if(c->v==a) // adauga xa
                    {
                        p=new numar;
                        p->v=xa;
                        p->urm=c->urm;
                        c->urm=p;
                        c=p->urm;
                    }
                    else
                        c=c->urm;
                }
                cout<<"Lista dupa adaugare dupa element este: ";
                parcurgere_lista(cap);
                break;
            case 3: // adaugare la sfarsit
                // ajungem la sfarsitul listei
                numar *c;
                c=cap;
                while(c->urm!=NULL)
                    c=c->urm;
                // la iesirea din while c este ultimul element din lista
                p=new numar;
                p->v=xa;
                p->urm=NULL;
                c->urm=p;
                cout<<"Lista dupa adaugare la sfarsit este: ";
                parcurgere_lista(cap);
                break;
            case 0:
                cout<<"A incheiat adaugarea in lista"<<endl;
            default:
                cout<<"Optiune gresita!"<<endl;
                break;
        }// end switch
    }while(op!=0);
    return cap;
}
// functii pentru liste dublu inlantuite
lista2 *creare_lista_dublu_inlantuita()
{
    int x, n, i;
    lista2 *cap;
    numar2 *c;
    // scriem primul element al listei
    cout<<"Primul element este x=";
    cin>>x;
    c=new numar2;
    c->v=x;
    c->prec=NULL;
    c->urm=NULL;
    cap=new lista2;
    cap->prim=c;
    cap->ultim=c;
    cout<<"Cate elemente scriem in lista n=";
    cin>>n;
    for(i=1; i<=n; i++)
    {
        // citeste o valoare si o adauga in lista dupa ultimul element
        cout<<"Elementul al "<<i+1<<"-lea este x=";
        cin>>x;
        c=new numar2;
        c->v=x;
        c->prec=cap->ultim;
        c->urm=NULL;
        (cap->ultim)->urm=c;
        cap->ultim=c;
    }
    return cap;
}
void parcurgere_inainte(lista2 *cap)
{
    numar2 *c;
    // parcurgere prim catre ultim
    c=cap->prim;
    while(c!=NULL)
    {
        cout<<c->v<<" ";
        c=c->urm;
    }
    cout<<endl;
}
void parcurgere_inapoi(lista2 *cap)
{
    numar2 *c;
    // parcurgere prim catre ultim
    c=cap->ultim;
    while(c!=NULL)
    {
        cout<<c->v<<" ";
        c=c->prec;
    }
    cout<<endl;
}
lista2 *adaugare_in_lista_dublu_inlantuita(lista2 *cap)
{
    int optiune=1, xa, y;
    numar2 *c, *p;
    int nrl=0;
    do
    {
        cout<<"1. Adauga la inceput."<<endl;
        cout<<"2. Adauga dupa element."<<endl;
        cout<<"3. Adauga la sfarsit."<<endl;
        cout<<"0. A terminat adaugarea."<<endl;
        cout<<"Optiunea este: "; cin>>optiune;
        switch (optiune){
            case 1: // adauga la inceput
                cout<<"Valoare de adaugat xa = ";
                cin>>xa;
                c=new numar2;
                c->v=xa;
                c->prec=NULL;
                c->urm=cap->prim;
                (cap->prim)->prec=c;
                cap->prim=c;
                parcurgere_inainte(cap);
                break;
            case 2: // adauga dupa element
                cout<<"Valoare de adaugat xa = ";
                cin>>xa;
                cout<<"Valoare dupa care adaugam y = ";
                cin>>y;
                p=cap->prim;
                while (p!=NULL)
                {
                    if (p->v == y) // adauga element
                    {
                        nrl++;
                        c=new numar2;
                        c->v=xa;
                        c->urm=NULL;
                        if (p->urm != NULL)
                        {
                            c->urm=p->urm;
                            (p->urm)->prec=c;
                        }
                        c->prec=p;
                        p->urm=c;
                        p=c->urm;
                    }
                    else
                        p=p->urm;
                }
                cout<<"A adaugat "<<nrl<<"  elemente in lista"<<endl;
                parcurgere_inainte(cap);
                break;
            case 3: //adauga la sfarsit
                cout<<"Valoare de adaugat xa = ";
                cin>>xa;
                c=new numar2;
                c->v=xa;
                c->urm=NULL;
                c->prec=cap->ultim;
                (cap->ultim)->urm=c;
                cap->ultim=c;
                parcurgere_inainte(cap);
                break;
            case 0:
                cout<<"Am terminat de adaugat!"<<endl;
                break;
            default:
                cout<<"Optiune gresita!"<<endl;
                break;
        }//end switch
    }while(optiune!=0);
    return cap;
}
lista2 *stergere_din_lista_dublu_inlantuita(lista2 *cap)
{
    int s;
    numar2 *p, *desters;
    cout<<"Elementul de sters este s = ";
    cin>>s;
    // stergem, daca exista, elemente cu valaorea dde sters in cap->prim al listei
    while ((cap->prim)->v == s)
    {
        desters=cap->prim;
        cap->prim=(cap->prim)->urm;
        (cap->prim)->prec=NULL;
        delete desters;
    }
    p=(cap->prim)->urm;
    while (p!=NULL)
    {
        if (p->v == s)
        {
            // sterge elementul p
            if (p->urm == NULL) // p este ultimul element din lista
            {
                desters=p;
                (p->prec)->urm=NULL;
                cap->ultim=p->prec;
                delete desters;
                p=(cap->ultim)->urm;
            }
            else
                {
                    desters=p;
                    (p->prec)->urm=p->urm;
                    (p->urm)->prec=p->prec;
                    p=p->urm;
                    delete desters;
                }
        }
        else // daca p nu contine valoarea de sters
        p=p->urm;
    }
    return cap;
}
// functii pentru stive
punct *creare_stiva()
{
    punct *prim, *p;
    float v;
    char a;
    prim=new punct;
    cout<<"Valoarea primului punct din stiva este v= ";
    cin>>v;
    prim->x=v;
    prim->urm=NULL;
    do
    {
        cout<<"Adaugam elementul nou in stiva (d/n)?";
        cin>>a;
        if (((a=='d')||(a=='D')))
        {
            cout<<"Valoarea punct este v= ";
            cin>>v;
            p=new punct;
            p->x=v;
            p->urm=prim;
            prim=p;
        }
    }while ((a=='d')||(a=='D'));
    return prim;
}
void parcurgere_stiva(punct *prim)
{
   punct *c;
   c=prim;
   while(c)
   {
       cout<<c->x<<" ";
       c=c->urm;
   }
}
punct *adaugare_stiva(punct *prim)
{
    punct *p;
    p=new punct;
    float xa;
    cout<<"Valoarea de adaugat este xa= ";
    cin>>xa;
    p->x=xa;
    p->urm=prim;
    prim=p;
    return prim;
}
punct *stergere_stiva(punct *prim)
{
    punct *p;
    p=prim;
    prim=prim->urm;
    delete p;
    return prim;
}
numar *initializare_stiva(int x)
{
    numar *s;
    // s=capat stiva
    // scriem primul element al listei
    s=new numar;
    s->v=x;
    s->urm=NULL;
    return s;
}
void parcurgere_stiva(numar *s)
{
    numar *c;
    if(!s)
       cout<<"Stiva este vida!"<<endl;
    else
    {
        c=s;
        while(c!=NULL)
        {
            cout<<c->v<<endl;
            c=c->urm;
        }
    }
}
numar *stergere_din_stiva(numar *s)
{
    numar *desters;
    desters=s;
    s=s->urm;
    delete desters;
    return s;
}
numar *adaugare_in_stiva(numar *s)
{
    numar *a;
    int xa;
    cout<<"Valoare de adaugat in stiva xa= ";
    cin>>xa;
    a=new numar;
    a->v=xa;
    a->urm=s;
    s=a;
    return s;
}
numar *adaugare_element_in_stiva(numar *s, int xa)
{
    numar *a;
    a=new numar;
    a->v=xa;
    a->urm=s;
    s=a;
    return s;
}
monom *citeste_polinom()
{
    // polinom ca lista simpla inlantuita
    monom *p, *q, *u;
    float c;
    int n, i, g;
    cout<<"Primul coeficient este c= ";
    cin>>c;
    cout<<" pentru gradul g= ";
    cin>>g;
    p=new monom;
    p->coef=c;
    p->grad=g;
    p->urm=NULL;
    u=p; // ultimul element
    cout<<"Cate monoame are polinomul n= ";
    cin>>n;
    for(i=1; i<n; i++)
    {
        //citeste o valoare si o adauga in stiva
        cout<<"Monomul al "<<i+1<<"-lea are coeficientul c= ";
        cin>>c;
        cout<<" pentru gradul g= ";
        cin>>g;
        p=new monom;
        p->coef=c;
        p->grad=g;
        p->urm=NULL;
        u->urm=q;
        u=q;
    }
    return p;
}
void afiseaza_polinom(monom *p)
{
    monom *q;
    if(!p)
        cout<<"Polinomul este vid!"<<endl;
    else
    {
        q=p;
        while(q)
        {
            if(q->coef>=0)
                cout<<"+";
            cout<<q->coef<<"*x^"<<q->grad;
            q=q->urm;
        }
        cout<<endl;
    }
}
monom *creare_lista_polinom(monom *p1, monom *p2)
{
    monom *p, *c, *r, *u;
    p=new monom;
    p->grad=p1->grad;
    p->coef=p1->coef;
    p->urm=NULL;
    c=p1->urm;
    u=p; // u=ultimul element din lista p
    while(c!=NULL)
    {
        r=new monom;
        r->grad=c->grad;
        r->coef=c->coef;
        r->urm=NULL;
        u->urm=r;
        u=r;
        c=c->urm;
    }
    c=p2;
    while(c!=NULL)
    {
        r=new monom;
        r->grad=c->grad;
        r->coef=c->coef;
        r->urm=NULL;
        u->urm=r;
        u=r;
        c=c->urm;
    }
    p=p->urm;
    return p;
}
//monom *reducere_termeni(monom *p)
//{
//    monom *c, *c1, *r;
//    c=p;
//    while(c->urm!=NULL)
//    {
//        // compara gradul din c cu gradele monoamelor urmatoare
//        c1=c->urm;
//        r=c; // r=monomul dinaintea lui c1 (precedentul lui c1)
//        while(c1=!NULL)
//        {
//            if((c1!=NULL)==(c->grad))
//            {
//                c->coef=c->coef+c1->coef;
//                //c1 se sterge din lista p
//                r->urm=c1->urm;
//                c1=c1->urm;
//            }
//            else
//            {
//                r=c1;
//                c1=c1->urm;
//            }
//        }
//        c=c->urm;
//    }
//}
//monom *creare_lista_inmultire(monom *p1, monom*p2)
//{
//    monom *t, *r, *u, *c1, *c2;
//    t=new monom;
//    t->grad=0;
//    t->coef=0;
//    t->urm=NULL;
//    u=t; // u=ultimul element din lista t
//    c1=p1; // monom curent polinomului p1
//    while(c1!=NULL)
//    {
//        c2=p2;
//        while(c2!=NULL)
//        {
//            // adauga in t produsul monoamelor c1, c2
//            r=new monom;
//            r->grad=(c1->grad)+(c2->grad);
//            r->coef=(c1->coef)*(c2->coef);
//            r->urm=NULL;
//            r->urm=r;
//            u=r;
//            c2=c1->urm;
//        }
//        c1=c1->urm;
//    }
//    // se face reducerea de termeni asemenea
//    t=reducere_termeni(t);
//    // se sterge monomul zero de la inceput
//    t=t->urm;
//    // afisam t;
//    return t;
//}
// functii pentru corzi
lista2 *creare_coarda()
{
    lista2 *c;
    c=creare_lista_dublu_inlantuita();
    return c;
}
lista2 *adaugare_coarda(lista2 *c)
{
    numar2 *p;
    int va;
    cout<<"Valoarea de adaugat este va= ";
    cin>>va;
    p=new numar2;
    p->v=va;
    p->prec=c->ultim;
    p->urm=NULL;
    (c->ultim)->urm=p;
    c->ultim=p;
    return c;
}
lista2 *stergere_coarda(lista2 *c)
{
    numar2 *s;
    s=c->prim;
    ((c->prim)->urm)->prec=NULL;
    c->prim=(c->prim)->urm;
    delete s;
    return c;
}

int main()
{
    // variabile ale main-ului
    int op, op1, op2, op3, op4;
    float a, b, c;
    int n, i;
    float x[20];
    int y[20];
    int r1, c1, r2, c2;
    int rezultat, d;
    int nex;
    // main
    // do
    cout<<"PROGRAM ASD - 2021"<<endl<<endl;
    cout<<"Budeci Ana-Maria, 1331"<<endl;
    cout<<"________________________________"<<endl<<endl;
    do{
        cout<<endl<<"MENIU PRINCIPAL"<<endl<<"_____________________"<<endl;
        cout<<"1. Probleme simple de programare "<<endl;
        cout<<"2. Algoritmi de sortare "<<endl;
        cout<<"3. Liste, corzi, stive "<<endl;
        cout<<"4. Grafuri. Aplicatii."<<endl;
        cout<<"0. Terminare program."<<endl;
        cout<<endl;
        cout<<"Optiune meniu principal op= ";
        cin>>op;
        switch (op){
            case 1: // probleme simple de programare
                do{
                    cout<<endl<<"1. PROBLEME SIMPLE DE PROGRAMARE"<<endl<<endl;
                    cout<<"1.1. Rezolvare completa pentru ecuatia de gradul al doilea"<<endl;
                    cout<<"1.2. Inmultirea a doua matrice"<<endl;
                    cout<<"1.3. Verificare numar prim"<<endl;
                    cout<<"1.4. Trecerea unui numar din baza 10 in baza b=2,...,9"<<endl;
                    cout<<"1.0. Iesire din meniu 1. PROBLEME SIMPLE DE PROGRAMARE"<<endl;
                    cout<<"Optiune pentru meniu 1, op1= ";
                    cin>>op1;
                    switch (op1){
                        case 1: // rezolvarea ecuatiei de gradul 2
                            cout<<"Rezolva ecuatie a*x^2+b*x+c=0"<<endl;
                            cout<<"a= ";
                            cin>>a;
                            cout<<"b= ";
                            cin>>b;
                            cout<<"c= ";
                            cin>>c;
                            rezolva_ec2(a,b,c);
                            break;
                        case 2: // inmultirea a 2 matrici
                            cout<<"Inmultirea a doua matrice"<<endl;
                            cout<<"Introduceti randurile si coloanele primei matrice: ";
                            cout<<"r1= ";
                            cin>>r1;
                            cout<<"c1= ";
                            cin>>c1;
                            cout<<"Introduceti randurile si coloanele celei de-a doua matrice: ";
                            cout<<"r2= ";
                            cin>>r2;
                            cout<<"c2= ";
                            cin>>c2;
                            cout<<endl;
                            inmultirea_matricelor(r1,c1,r2,c2);
                            break;
                        case 3: // numar prim
                            cout<<"Introduceti un numar intreg: ";
                            cin>>n;
                            cout<<endl;
                            numar_prim(n);
                            break;
                        case 4: // schimbarea din baza 10 in baza b=2,...,9
                            cout<<"Introduceti numarul n in baza 10: ";
                            cin>>n;
                            cout<<"Introduceti baza in care doriti sa il schimbati: ";
                            cin>>i;
                            schimbare_baza(n,i);
                            break;
                        case 0:
                            cout<<"Terminat meniu 1. REZOLVAREA ECUATIEI DE GRADUL 2."<<endl;
                            break;
                        default:
                            cout<<"Optiune gresita!"<<endl;
                            break;
                    }// end switch op1 probleme simple de programare
                }while(op1!=0);
                break;
            case 2: // algoritmi de sortare
                do{
                    cout<<endl<<"2. ALGORITMI DE SORTARE"<<endl<<endl;
                    cout<<"2.1. Sortare prin metoda bulelor (bubble sort)"<<endl;
                    cout<<"2.2. Sortare prin selectie (selection sort)"<<endl;
                    cout<<"2.3. Sortare prin numarare (counting sort)"<<endl;
                    cout<<"2.4. Sortare prin contipore (merge sort)"<<endl;
                    cout<<"2.5. Sortare prin interclasare (quick sort)"<<endl;
                    cout<<"2.6. Sortare prin insertie (insertion sort)"<<endl;
                    cout<<"2.7. Sortare prin intertie din pas in pas (shell sort)"<<endl;
                    cout<<"2.8. Sortarea Radix  (radix sort)"<<endl;
                    cout<<"2.9. Cautarea unui element prin cautarea binara"<<endl;
                    cout<<"2.10. Cautarea unui element prin cautarea secventiala"<<endl;
                    cout<<"2.0. Iesire din meniu 2. ALGORITMI DE SORTARE"<<endl;
                    cout<<"Alege optiune meniu 2, op2= ";
                    cin>>op2;
                    switch (op2){
                        case 1: // bubble sort
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>x[i];
                            }
                            bubble_sort(n,x);
                            break;
                        case 2: // selection sort
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>x[i];
                            }
                            selection_sort(n,x);

                            break;
                        case 3: // counting sort
                            // n=sizeof(n)/sizeof(n[0]);
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            counting_sort(n,y);
                            afisare(n,y);
                            break;
                        case 4: // merge sort
                            // n=sizeof(n)/sizeof(n[0]);
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            mergeSort(y,0,n-1);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 5: // quick sort
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            quickSort(y,0,n-1);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 6: // insertion sort
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            insertionSort(y,n);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 7: // shell sort
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            shellSort(y,n);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 8: // radix sort
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            radixsort(y,n);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 9: // cautarea binara
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            cout<<"Introduceti numarul cautat: ";
                            cin>>d;
                            shellSort(y,n);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            rezultat=cautarea_binara(y,d,0,n-1);
                            if(rezultat==-1)
                                cout<<"Nu se gaseste";
                            else
                                cout<<"Elementul a fost gasit in sir";
                            break;
                        case 10: // cautarea secventiala
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            cout<<"Introduceti numarul cautat: ";
                            cin>>d;
                            shellSort(y,n);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            rezultat=cautarea_secventiala(y,n,d);
                            if(rezultat==0)
                                cout<<"Nu se gaseste";
                            else
                                cout<<"Elementul a fost gasit in sir";
                            break;
                        case 0:
                            cout<<"Terminat meniu 2. ALGORITMI DE SORTARE."<<endl;
                            break ;
                        default:
                            cout<<"Optiune gresita!"<<endl;
                            break;
                    } // end switch op2 algoritmi de sortare
                }while(op2);
                break;
            case 3: // liste, cozi, stive
                do{
                    cout<<endl<<"3. LISTE, CORZI, STIVE"<<endl<<endl;
                    cout<<"3.1. Operatii cu liste simplu inlantuite: creare, parcurgere, agaugare, stergere, modificare"<<endl;
                    cout<<"3.2. Operatii cu liste dublu inlantuite: creare, parcurgere, agaugare, stergere, modificare"<<endl;
                    cout<<"3.3. Operatii cu stive: creare, parcurgere, adaugare, stergere"<<endl;
                    cout<<"3.4. Operatii cu corzi: creare, parcurgere, adaugare, stergere"<<endl;
                    cout<<"3.5. Operatii cu crearea unei liste de numere intregi ordonata"<<endl;
                    cout<<"3.6. Interclasarea a doua liste ordonate"<<endl;
                    cout<<"3.7. Adunarea polinoamelor"<<endl;
                    cout<<"3.8. Inmultirea polinoamelor"<<endl;
                    cout<<"3.9. Verificare corectitudine paranteze in expresie aritmetica"<<endl;
                    cout<<"3.0. Iesire din meniu 3. LISTE, CORZI, STIVE"<<endl;
                    cout<<"Alege optiune meniu 3, op3= ";
                    cin>>op3;
                    switch (op3){
                        case 1: // operatii cu liste simplu inlantuite: creare, parcurgere, agaugare, stergere, modificare
                            numar *cap_lista;
                            // creare lista
                            cap_lista=creare_lista();
                            // parcurgere lista
                            cout<<"Lista dupa creare este: ";
                            parcurgere_lista(cap_lista);
                            cout<<endl;
                            // adaugare in lista
                            int xa;
                            // adaugare la inceput
                            cout<<"Valoarea de adaugat in lista xa= ";
                            cin>>xa;
                            cap_lista=adaugare_in_lista(cap_lista,xa);
                            cout<<"Lista dupa adaugare in lista este: ";
                            // parcurgere lista dupa adaugare la inceput
                            parcurgere_lista(cap_lista);
                            // parcurgere lista
                            // stergere din lista
                            int s;
                            cout<<"Sterge elementele cu valoarea= ";
                            cin>>s;
                            cap_lista=stergere(cap_lista,s);
                            // parcurgere lista dupa stergere
                            cout<<"Lista dupa stergere este: ";
                            parcurgere_lista(cap_lista);
                            cout<<endl;
                            break;
                        case 2: // operatii cu liste dublu inlantuite: creare, parcurgere, agaugare, stergere, modificare
                            lista2 *l2;
                            // creare lista dublu inlantuita
                            l2=creare_lista_dublu_inlantuita();
                            cout<<"Lista inainte este: ";
                            parcurgere_inainte(l2);
                            cout<<"Lista inapoi este: ";
                            parcurgere_inapoi(l2);
                            // adaugare elemente in lista dublu inlantuita
                            l2=adaugare_in_lista_dublu_inlantuita(l2);
                            cout<<"Dupa adaugare:"<<endl;
                            cout<<"Lista inainte este: ";
                            parcurgere_inainte(l2);
                            cout<<"Lista inapoi este: ";
                            parcurgere_inapoi(l2);
                            // stergere elemente cu valoare data din lista dublu inlantuita
                            l2=stergere_din_lista_dublu_inlantuita(l2);
                            cout<<"Dupa stergere:"<<endl;
                            cout<<"Lista inainte este: ";
                            parcurgere_inainte(l2);
                            cout<<"Lista inapoi este: ";
                            parcurgere_inapoi(l2);
                            break;
                        case 3: // operatii cu stive: creare, parcurgere, adaugare, stergere
                            punct *stiva;
                            stiva=creare_stiva();
                            cout<<"Stiva este: ";
                            parcurgere_stiva(stiva);
                            cout<<endl;
                            // adaugare in stiva
                            stiva=adaugare_stiva(stiva);
                            cout<<"Stiva dupa agaugare este: ";
                            parcurgere_stiva(stiva);
                            cout<<endl;
                            // stergere din stiva
                            stiva=stergere_stiva(stiva);
                            cout<<"Stiva dupa stergere este: ";
                            parcurgere_stiva(stiva);
                            cout<<endl;
                            break;
                        case 4: // operatii cu corzi: creare, parcurgere, adaugare, stergere
                            lista2 *coarda;
                            coarda=creare_coarda();
                            cout<<"Coarda este: ";
                            parcurgere_inainte(coarda);
                            cout<<endl;
                            // adaugare in coarda
                            coarda=adaugare_coarda(coarda);
                            cout<<"Coarda dupa adaugare: ";
                            parcurgere_inainte(coarda);
                            cout<<endl;
                            // stergere din coarda
                            coarda=stergere_coarda(coarda);
                            cout<<"Coarda dupa stergere este: ";
                            parcurgere_inainte(coarda);
                            cout<<endl;
                            break;
                        case 5: // operatii cu crearea unei liste de numere intregi ordonata
                            break;
                        case 6: // interclasarea a doua liste ordonate
                            break;
                        case 7: // adunarea polinoamelor
                            monom *p1, *p2, *p;
                            cout<<"p1 este: ";
                            p1=citeste_polinom();
                            cout<<endl<<"p2 este: ";
                            p2=citeste_polinom();
                            cout<<"p1= ";
                            afiseaza_polinom(p1);
                            cout<<"p2= ";
                            afiseaza_polinom(p2);
                            p=creare_lista_polinom(p1,p2);
                            cout<<endl<<"Polinomul dupa lipire este: ";
                            afiseaza_polinom(p);
                            // pastreaza polinoamele citite
                            // afiseaza suma
                            // parcurgem polinomul suma si pentru fiecare element cautam elemente de acelasi grad care urmeaza dupa elementul curent
                            // cand gaseste acelasi grad reduce elementul astfel: adauga coeficientul sau la elementul curent si apoi il sterge din lista suma
                            // afiseaza suma dupa ce a redus termenii asemenea
                            break;
                        case 8: // inmultirea polinoamelor
//                            monom *p1, *p2, *p;
//                            cout<<"p1 este: ";
//                            p1=citeste_polinom();
//                            cout<<endl<<"p2 este: ";
//                            p2=citeste_polinom();
//                            cout<<"p1= ";
//                            afiseaza_polinom(p1);
//                            cout<<"p2= ";
//                            afiseaza_polinom(p2);
//                            p=creare_lista_inmultire(p1,p2);
//                            cout<<endl<<"Polinomul dupa inmultire este: ";
//                            afiseaza_polinom(p);
                            break;
                        case 9: // verificare corectitudine paranteze in expresie aritmetica
                            numar *sp;
                            char expresie[200]; // presupunem ca expresia nu are spatii
                            cout<<"Expresia este: ";
                            cin>>expresie;
                            nex=strlen(expresie);
                            cout<<"Lungimea expresiei= "<<nex<<endl<<expresie<<endl;
                            // se scriu parantezele intr-o stiva de numere intregi
                            sp=new numar;
                            sp=NULL;
                            for (i=0; i<nex; i++)
                            {
                                bool ok=true; // true daca expresia e corecta
                                switch(expresie[i]){
                                    case '{':
                                        cout<<"A gasit {"<<endl;
                                        // scrie 1 in stiva
                                        if(sp) // stiva nu este vida, adauga in stiva
                                            sp=adaugare_element_in_stiva(sp,1);
                                        else
                                            sp=initializare_stiva(1);
                                        parcurgere_stiva(sp);
                                        break;
                                    case '[':
                                        cout<<"A gasit ["<<endl;
                                        // scrie 2 in stiva
                                        if(sp) // stiva nu este vida, adauga in stiva
                                            sp=adaugare_element_in_stiva(sp,2);
                                        else
                                            sp=initializare_stiva(2);
                                        parcurgere_stiva(sp);
                                        break;
                                    case '(':
                                        cout<<"A gasit ("<<endl;
                                        // scrie 3 in stiva
                                        if(sp) // stiva nu este vida, adauga in stiva
                                            sp=adaugare_element_in_stiva(sp,3);
                                        else
                                            sp=initializare_stiva(3);
                                        parcurgere_stiva(sp);
                                        break;
                                    case ')':
                                        // verifica daca primul element in stiva este 3 si il sterge, altfel este expresia gresita=>ok=false
                                        if(sp->v==3)
                                            sp=stergere_din_stiva(sp);
                                        else
                                            ok=false;
                                        break;
                                    case ']':
                                        // verifica daca primul element in stiva este 2 si il sterge, altfel este expresia gresita=>ok=false
                                        if(sp->v==2)
                                            sp=stergere_din_stiva(sp);
                                        else
                                            ok=false;
                                        break;
                                    case '}':
                                        // verifica daca primul element in stiva este 1 si il sterge, altfel este expresia gresita=>ok=false
                                        if(sp->v==1)
                                            sp=stergere_din_stiva(sp);
                                        else
                                            ok=false;
                                        break;
                                    default:
                                        break;
                                } // end switch
                                if(!ok)
                                {
                                    cout<<"Expresie gresita! Parantezele nu se potrivesc.";
                                    break;
                                }
                            }
                            cout<<endl;
                            parcurgere_stiva(sp);
                            // daca stiva este vida si ok==true atunci expresia este corecta, altfel nu este corecta
                            if(sp)
                                cout<<"Stiva nu este vida: sunt paranteze deschise care nu au pereche!"<<endl;
                            else
                                cout<<"Expresia este corecta!"<<endl;
                            break;
                        case 0:
                            cout<<"Terminat meniu 3. LISTE, CORZI, STIVE."<<endl;
                            break;
                        default:
                            cout<<"Optiune gresita!"<<endl;
                            break;
                    } // end switch op3 liste, cozi, stive
                }while(op3);
                break;
            case 4: // grafuri; aplicatii
                do
                {
                    cout<<endl<<"4. GRAFURI. APLICATII"<<endl<<endl;
                    cout<<"4.1. Reprezentare matrice de adiacenta <=> lista de noduri"<<endl;
                    cout<<"4.2. Reprezentare matrice de adiacenta <=> lista de muchii"<<endl;
                    cout<<"4.3. Reprezentare lista de noduri <=> lista de muchii"<<endl;
                    cout<<"4.4. Moduri de parcurgere grafuri: in adancime si in latime"<<endl;
                    cout<<"4.5. Verificare existenta drum intre oricare doua noduri"<<endl;
                    cout<<"4.0. Iesire din meniu 4. GRAFURI. APLICATII"<<endl;
                    cout<<"Alege optiune meniu 4, op4= ";
                    cin>>op4;
                    switch (op4){
                        case 1: // reprezentare matrice de adiacenta <=> lista de noduri
                            break;
                        case 2: // reprezentare matrice de adiacenta <=> lista de muchii
                            break;
                        case 3: // reprezentare lista de noduri <=> lista de muchii
                            break;
                        case 4: // moduri de parcurgere grafuri: in adancime si in latime
                            break;
                        case 5: // verificare existenta drum intre oricare doua noduri
                            break;
                        case 0:
                            cout<<"Terminat meniu 4. GRAFURI. APLICATII."<<endl;
                            break;
                        default:
                            cout<<"Optiune gresita!"<<endl;
                            break;
                    } // end switch grafuri
                }while(op4!=0); // end do grafuri
                break;
            case 0:
                cout<<"Terminare program principal. La revedere!"<<endl;
                break;
            default:
                cout<<"Optiune gresita!"<<endl;
                break;
        } // end switch meniu principal
    }while(op!=0);
    return 0;
}
