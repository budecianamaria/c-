#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;
int main()
{
    int op, n=0;
    int i, j, mIndex=0;
    char *str=new char [100];
    char temp, minstr;
    cout<<"PROIECT ASD - 2021"<<endl<<endl;
    cout<<"Budeci Ana-Maria, 1331a "<<endl;
    cout<<"________________________________"<<endl;
    do{
        cout<<endl<<"MENIUL PRINCIPAL"<<endl<<"_____________________"<<endl;
        cout<<"1. Sortarea prin metoda bulelor pentru siruri de caractere (bubble sort)."<<endl;
        cout<<"2. Sortarea prin selectie pentru siruri de caractere (selection sort)."<<endl;
        cout<<"3. Sortarea prin insertie pentru siruri de caractere (insertion sort)."<<endl;
        cout<<"4. Sortare prin intertie din pas in pas pentru siruri de caractere (shell sort)."<<endl;
        cout<<"0. Sfarsitul programului."<<endl;
        cout<<endl;
        cout<<"Optiunea meniului principal este op= ";
        cin>>op;
        cout<<endl;
        switch (op){
            case 1: // bubble sort
                cout<<"Introduceti sirul: ";
                cin>>str; // memoreaza n caractere incepand de la 0 la n-1 caractere
                n=strlen(str);
                cout<<"Lungimea sirului este: "<<n<<endl;
                for (i=0; i<n-1; i++)
                {
                    for (j=i+1; j<n; j++)
                    {
                        if (str[i]>str[j]) // daca valoarea anteriora are o valoare ascii mai mare decat urmatoarea
                        {
                            temp=str[i];
                            str[i]=str[j];
                            str[j]=temp;
                        }
                    }
                }
                cout<<"Sirul ordonat este: "<<str<<endl;
                break;
            case 2: // selection sort
                cout<<"Introduceti sirul: ";
                cin>>str; // memoreaza n-1 caractere
                n=strlen(str);
                cout<<"Lungimea sirului este: "<<n<<endl;
                for (i=0; i<n-1; i++)
                {
                    // determina elementul minim in matricea nesortata
                    mIndex=i;
                    minstr=str[i];
                    for (j=i+1; j<n; j++)
                    {
                        // verificam daca minstr este mai mare decat str[j]
                        if (minstr>str[j])
                        {
                            // facem str[j]=minstr și actualizam mIndex
                            minstr=str[j];
                            mIndex=j;
                         }
                    }
                        // schimbam minimul cu primul element
                        if (mIndex!=i)
                        {
                            temp=str[i];
                            str[i]=str[mIndex];
                            str[mIndex]=temp;
                        }
                }
                cout<<"Sirul ordonat este: "<<str<<endl;
                break;
            case 3: // insertion sort
                cout<<"Introduceti sirul: ";
                cin>>str; // memoreaza n-1 caractere
                n=strlen(str);
                cout<<"Lungimea sirului este: "<<n<<endl;
                for(i=1; i<n; i++)
                {
                    temp=str[i];
                    j=i-1;
                    // comparam cheia cu fiecare element din stanga acestuia pana cand se gaseste un element mai mic decat este
                    // pentru ordinea descrescatoare, schimbam k<sirul[j] la k>sirul[j]
                    while(temp<str[j] && j>=0)
                    {
                        str[j+1]=str[j];
                        --j;
                    }
                    str[j+1]=temp;
                }
                cout<<"Sirul ordonat este: "<<str<<endl;
                break;
            case 4: // shell sort
                cout<<"Introduceti sirul: ";
                cin>>str; // memoreaza n-1 caractere
                n=strlen(str);
                cout<<"Lungimea sirului este: "<<n<<endl;
                // rearanjam elementele la fiecare interval n/2, n/4, n/8,...,1  intervale
                for(i=n/2; i>0; i/=2)
                {
                    for(j=i; j<n; j+=1)
                    {
                        temp=str[j];
                        int z;
                        for(z=j; z>=i && str[z-i]>temp; z-=i)
                        {
                            str[z]=str[z-i];
                        }
                        str[z]=temp;
                    }
                }
                cout<<"Sirul ordonat este: "<<str<<endl;
                break;
            case 0:
                cout<<"Terminarea programului principal. La revedere!"<<endl;
                break;
            default:
                cout<<"Optiunea gresita! Alegeti alta optiune."<<endl;
                break;
        } // end switch meniu principal
    }while(op!=0);
    return 0;
}
