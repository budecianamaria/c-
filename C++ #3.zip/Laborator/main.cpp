#include <iostream>
#include <math.h> // pentru functia fabs
#include <iomanip> // pentru functia scientific<<setprecision(10)
#include <stdio.h>
#include <string.h>
// Program subgrupa 1331a, FSA
using namespace std;
// BUDECI ANA-MARIA LAVINIA
// Rezolvari din Capitolul 1: EXEMPLE DE ALGORITMI
//      1.1. Norme de matrice
//      1.2. Metoda coardei pentru ecuatii in multimea numerelor reale
//      1.3. Metoda tangentei
// Rezolvari din Capitolul 2: METODE BACKTRACKING
//      2.1. Generarea permutarilor
//      2.2. Generarea combinarilor
//      2.3. Generarea aranjamentelor
//      2.4. Problema reginelor
//      2.5. Problema turelor
//      2.6. Problema calutilor
//      2.8. Problema parantezelor
// Rezolvari din Capitolul 3: RECURSIVITATE
//      3.1. Factorialul
//      3.2. Sirul Fibonacci
//      3.3. Functia Ackerman (recursiva)
//      3.4. Functia Ackerman (iterativa)
//      3.6. Backtracking recursiv
//      3.7. Descompunere in factori primi (recursiv)
//      3.8. Trecerea din baza 10 in baza b de la 2 la 9
//      3.9. Numarul de partitii ale unei multimi
//      3.10. Recursivitate indirecta: miscarea unui punct pe ecran
// Rezolvari din Capitolul 4: DIVIDE ET IMPERA
//      4.1. Sortarea prin interclasare (merge sort)
//      4.2. Sortarea rapida (quick sort)
//      4.3. Cautarea binara
//      4.4. Maximul unui sir de numere (recursiv)
//      4.5. Minimul unui sir de numere (recursiv)
//      4.6. Turnurile din Hanoi
// Rezolvari din Capitolul 5: METODA GREEDY
//      5.2. Plata unei sume s daca avem numar nelimitat de bacnote
// Rezolvari din Capitolul 6: PROGRAMARE DINAMICA
//      6.1. Produs de matrice cu numar minim de inmultiri
//      6.2. Suma maxima in triunghiul de numere
//      6.3. Verificare compunere sir intr-un alfabet dat
// Rezolvari din Capitolul 7: METODA BRANCH AND BOUND
// Rezolvari din Capitolul 8: METODE PROBALISTE (ALGORITMI PROBABILISTI)
//      8.1. Acul lui Buffon // nu afiseaza rezultatul


// variabilele globale
int na, st[10], k, p;
float pi=3.1415;

// tipuri de variabile
typedef struct numar
{
    int v;
    numar *urm;
}numar;
// functiile utilizatorului
// norme de matrice
float norma_infinit(int n, float M[10][10])
{
    float ni, suma;
    int i, j;
    ni=0;
    for (i=0; i<n; i++)
    {
        suma=0;
        for (j=0; j<n; j++)
            suma=suma+fabs(M[i][j]);
        if (suma>ni)
            ni=suma;
    }
    return ni;
}
float norma1(int n, float M[10][10])
{
    float n1, suma;
    int i, j;
    n1=0;
    for (j=0; j<n; j++)
    {
        suma=0;
        for (i=0; i<n; i++)
            suma=suma+fabs(M[i][j]); // fabs=functia pentru calculul modulului unui numar
        if (suma>n1)
            n1=suma;
    }
    return n1;
}
// metoda coardei pentru ecuatii in multimea numerelor reale
float f(float x)
{
    return x*x-3;
}
void metoda_coardei()
{
    float a, b, eps, x1, x2, er;
    int n=1; // n=numarul de interatii (pasi)
    cout<<"Intervalul de rezolvare al ecuatiei este: ";
    cin>>a>>b;
    cout<<"Marja de eroare este: ";
    cin>>eps;
    x1=a-f(a)*(b-a)/(f(b)-f(a));
    cout<<"Prima aproximare a solutiei este: "<<scientific<<setprecision(10)<<x1<<endl;
    do{
            x2=x1-f(x1)*(b-x1)/(f(b)-f(x1));
            cout<<scientific<<setprecision(10)<<x2<<endl; // setprecision(10)=calcului unei aproximari a unei colutii cu 10 zecimale
            er=fabs(x2-x1);
            x1=x2;
            n++;
    }while(er>eps);
    cout<<"Solutia cu aproximatia "<<eps<<" este: "<<scientific<<setprecision(10)<<x2<<endl;
    cout<<" obtinuta in "<<n<<" iteratii"<<endl;
}
// metoda tangenei
double fDerivat(double x)
{
    return 2*x;
}
void metoda_tangentei()
{
    float eps, x0, x, er, y;
    int a, b, k=0;
    cout<<"Dati intervalul de rezolvare al ecuatiei: ";
    cin>>a;
    cin>>b;
    cout<<"Dati marja de eroare: ";
    cin>>eps;
    cout<<"Dati x0= ";
    cin>>x0;
    x=x0-f(x0)/fDerivat(x0);
    do{
        y=x-f(x)/fDerivat(x);
        er=fabs(y-x);
        k++;
        cout<<"La pasul "<<k<<" solitia are valoarea "<<y<<endl;
        x=y;
    }while(er>eps);
}
// generarea permutarilor
int bun1()
{
    int i;
    for (i=1;i<k;i++)
        if (st[k]==st[i])
            return 0;
    return 1;
}
int solutie1()
{
    if (na==k)
        return 1;
    else
        return 0;
}
void afisare1()
{
    int i;
    for (i=1;i<=na;i++)
        cout<<st[i]<<" ";
    cout<<endl;
}
void bkt1()
{
    k=1;
    while(k>0)
        if (st[k]<na)
        {
            st[k]=st[k]+1;
            if (bun1())
            {
                if (solutie1())
                    afisare1();
                else
                    k++;
            }
        }
        else
        {
            st[k]=0;
            k--;
        }
}
// generarea combinarilor
int bun2()
{
    if (k>1)
        if (st[k]<=st[k-1])
            return 0;
    return 1;
}
int solutie2()
{
    if (p==k)
        return 1;
    else
        return 0;
}
void afisare2()
{
    int i;
    for (i=1;i<=p;i++)
        cout<<st[i]<<" ";
    cout<<endl;
}
void bkt2()
{
    k=1;
    while(k>0)
        if (st[k]<na)
        {
            st[k]=st[k]+1;
            if (bun2())
            {
               if (solutie2())
                    afisare2();
                else
                    k++;
            }
        }
        else
        {
            st[k]=0;
            k--;
        }
}
// generarea aranjamentelor
int bun3()
{
    int i;
    for (i=1;i<k;i++)
        if (st[k]==st[i])
            return 0;
    return 1;
}
int solutie3()
{
    if (p==k)
        return 1;
    else
        return 0;
}
void afisare3()
{
    int i;
    for (i=1;i<=p;i++)
        cout<<st[i]<<" ";
    cout<<endl;
}
void bkt3()
{
    k=1;
    while(k>0)
        if (st[k]<na)
        {
            st[k]=st[k]+1;
            if (bun3())
            {
                if (solutie3())
                    afisare3();
                else
                    k++;
            }
        }
        else
        {
            st[k]=0;
            k--;
        }
}
// problema reginelor
bool validare_regine(int y, int k, int x[10])
{
    int j;
    for (j=0; j<=k-1; j++)
        if ((x[j]==y)||(fabs(y-x[j])==fabs(k-j)))
            return false;
    return true;
}
void problema_reginelor()
{
    int n, k, v, x[10], i, a;
    int nr_solutii=0;
    cout<<"Numarul reginelor este: ";
    cin>>n;
    k=0;
    x[0]=-1;
    while (k>-1)
    {
        v=0;
        while ((v==0)&&((x[k]+1)<=(n-1)))
        {
            x[k]=x[k]+1;
            if (validare_regine(x[k],k,x))
                v=1;
        }
        if (v==0)
            k=k-1;
        else
        {
            if (k==(n-1))
            {
                nr_solutii++;
                for(i=0; i<=n-1; i++)
                {
                    for (a=0; a<=n-1; a++)
                    {
                        if (a!=x[i])
                            cout<<"-"<<" ";
                        else
                            cout<<"*"<<" ";
                    }
                    cout<<endl;
                }
                cout<<endl;
            }
            else
            {
                k=k+1;
                x[k]=-1;
            }
        }
    }
    cout<<"Numarul solutiilor este: ";
    cout<<nr_solutii<<endl<<endl;
}
// problema turelor
void afisareVector(int x[20],int n)
{
    for(int i=1;i<=n;i++)
        cout<<x[i]<<' ';
    cout<<endl;
}
bool validareTure(int y,int k,int x[20])
{
    for(int j=1;j<k;j++)
        if(y==x[j])
            return false;
    return true;
}
void generareTure(int n)
{
    int k=1,nr_sol=0,v=0,x[20]={0};
    x[1]=0;
    while(k>0)
    {
        v=0;
        while(v==0 && x[k]+1<=n)
        {
            x[k]=x[k]+1;
            if(validareTure(x[k],k,x)==true)
                v=1;
        }
        if(v==0)
            k--;
        else
        {
            if(k==n)
            {
                nr_sol++;
                afisareVector(x,n);
            }
            else
            {
                k++;
                x[k]=0;
            }

        }
    }
    cout<<"Numarul de posibilitati: "<<nr_sol<<endl;
}
// problema calutilor
bool validareCaluti(int y,int k,int x[20])
{
    if((x[k]-2==x[k-1])||(x[k]+2==x[k+1]) || ((x[k]-1==x[k-2])) || (x[k]+1==x[k-2]))
            return false;
    return true;
}
void generareCaluti(int n)
{
    int k=1,nr_sol=0,v=0,x[20]={0};
    x[1]=0;
    while(k>0)
    {
        v=0;
        while(v==0 && x[k]+1<=n)
        {
            x[k]=x[k]+1;
            if(validareCaluti(x[k],k,x)==true)
                v=1;
        }
        if(v==0)
            k--;
        else
        {
            if(k==n)
            {
                nr_sol++;
                afisareVector(x,n);
            }
            else
            {
                k++;
                x[k]=0;
            }

        }
    }
    cout<<"Numarul de posibilitati: "<<nr_sol<<endl;
}
// problema parantezelor
numar *initializare_stiva(int x)
{
    numar *s;
    // s=capat stiva
    // scriem primul element al listei
    s=new numar;
    s->v=x;
    s->urm=NULL;
    return s;
}
void parcurgere_stiva(numar *s)
{
    numar *c;
    if(!s)
       cout<<"Stiva este vida!"<<endl;
    else
    {
        c=s;
        while(c!=NULL)
        {
            cout<<c->v<<endl;
            c=c->urm;
        }
    }
}
numar *stergere_din_stiva(numar *s)
{
    numar *desters;
    desters=s;
    s=s->urm;
    delete desters;
    return s;
}
numar *adaugare_element_in_stiva(numar *s, int xa)
{
    numar *a;
    a=new numar;
    a->v=xa;
    a->urm=s;
    s=a;
    return s;
}
// factorialul
int factorial(int n)
{
    int f;
    if(n==0)
        return 1;
    else
        f=factorial(n-1)*n;
    return f;
}
// sirul fibonacci
int fibonacci(int n)
{
    if (n==0)
    {
        cout<<"Sirul Fibonacci a fost indexat de la 1";
        return 0;
    }
    if (n==1 || n==2)
        return 1;
    return fibonacci(n-2)+fibonacci(n-1);
}
// functia Ackerman (recursiva)
long long ack(long m, long n)
{
    if (!m)
        return n+1;
    else
        if (!n)
            return ack(m-1,1);
        else
            return ack(m-1,ack(m,n-1));
}
// functia Ackerman (iterativa)
void ackermannIterativ(int k)
{
    int m, n, a[100]={0};
    cout<<"m=";
    cin>>m;
    cout<<"n=";
    cin>>n;
    a[1]=m;
    a[2]=n;
    while(k>1)
    {
        if(a[k-1]==0)
        {
            a[k-1]=a[k]+1;
            k--;
        }
        else if(a[k]==0)
        {
            a[k-1]=a[k-1]-1;
            a[k]=1;
        }
        else
        {
            a[k+1]=a[k]-1;
            a[k]=a[k-1];
            a[k-1]=a[k-1]-1;
            k++;
        }
    }
    cout<<a[1]<<endl;
}
// backtracking recursiv
void afiseazaRec(int st[20],int n)
{
    for(int i=1;i<=n;i++)
        cout<<st[i]<<' ';
    cout<<endl;
}
bool validRecursiv(int st[20],int k)
{
    for(int i=1;i<k;i++)
        if(st[i]==st[k])
            return false;
    return true;
}
void backT(int st[20],int k,int n)
{
    for(int i=1;i<=n;i++)
    {
        st[k]=i;
        if(validRecursiv(st,k)==true)
        {
            if(k==n)
                afiseazaRec(st,n);
            else
                backT(st,k+1,n);
        }
    }
}
// descompunere in factori primi (recursiv)
void factori_primi(int n)
{
    int d,p=0;
    if(n%2==0)
    {
        while(n%2==0)
        {
            p++;
            n=n/2;
        }
        cout<<2<<" de "<<p<<" ori"<<endl;
    }
    d=3;
    while(n>1)
    {
        if(n%d==0)
        {
            p=0;
            while(n%d==0)
            {
                p++;
                n=n/d;
            }
            cout<<d<<" de "<<p<<" ori"<<endl;
        }
        else
            d+=2;
        if(n>1&&d*d>n)
        {
            cout<<n<<" de "<<1<<" ori"<<endl;
            break;
        }
    }
}
// trecerea din baza 10 in baza b de la 2 la 9
void schimbare_baza(int n, int i)
{
    int x=0, rest=0, p=1;
    while(n!=0)
    {
        cout<<n<<" : "<<i<<" = ";
        rest=n%i;
        n=n/i;
        cout<<n<<" rest "<<rest<<endl;
        x=x+rest*p;
        p=p*10;
    }
}
// numarul de partitii ale unei multimi
int partitie(int n,int k)
{
    if(k==1 || k==n)
        return 1;
    if(k==2)
        return ((pow(2,n-1))-1);
    if(k>n)
        return 0;
    return partitie(n-1,k-1)+k*partitie(n-1,k);
}
// recursivitate indirecta: miscarea unui punct pe ecran
void coborare(int l,int n);
void urcare(int l,int n)
{
    if(l==1)
        coborare(l+1,n);
    else
        urcare(l-1,n);
}
void coborare(int l,int n)
{
    if(l==n)
        urcare(l-1,n);
    else
        coborare(l+1,n);

}
// sortarea prin interclasare (merge sort)
void merge_sort(int arr[], int p, int q, int r)
{
    // crearea L<-A[p..q] si M<-A[q+1..r]
    int n1=q-p+1;
    int n2=r-q;
    int L[n1], M[n2];
    for (int i=0; i<n1; i++)
        L[i]=arr[p+i];
    for(int j=0; j<n2; j++)
        M[j]=arr[q+1+j];
    // mentinem indicele curent al sub-tablourilor si al sirului principal
    int i, j, k;
    i=0;
    j=0;
    k=p;
    // pana cand ajungem la fiecare capat al lui L sau M, alegem mai mare dintre elementele L si M si le plasam in pozitia corecta la A[p..r]
    while(i<n1 && j<n2)
    {
        if(L[i]<=M[j])
        {
            arr[k]=L[i];
            i++;
        }
        else
        {
            arr[k]=M[j];
            j++;
        }
        k++;
    }
    // cand ramanem fara elemente in L sau M, ridicam elementele ramase si le introducem in A[p..r]
    while(i<n1)
    {
        arr[k]=L[i];
        i++;
        k++;
    }
    while(j<n2)
    {
        arr[k]=M[j];
        j++;
        k++;
    }
}
void mergeSort(int arr[], int l, int r)
{
    // impartim sirul in doua subsiruri, sortandu-le si imbinatindu-le
    if(l<r)
    {
        // m este punctul unde sirul se divide in 2 subsiruri
        int m=l+(r-l)/2;
        mergeSort(arr,l,m);
        mergeSort(arr,m+1,r);
        // imbinarea subsirurilor sortati
        merge_sort(arr,l,m,r);
    }
}
void afisare(int n, int x[20])
{
    // functia de afisare a sirului
    int i;
    for(i=0; i<n; i++)
        cout<<x[i]<<" ";
    cout<<endl;
}
// sortarea rapida (quick sort)
void inversare(int *a, int *b)
{
    // functia de a schimba pozitia elementelor
    int t=*a;
    *a=*b;
    *b=t;
}
int partitie(int arr[], int low, int high)
{
    // functia de partitionare a sirului pe baza elementului pivot
    // selectarea elementului pivoit
    int pivot=arr[high];
    int i=(low-1);
    // punem elementele mai mici decat pivotul in stanga și mai mare decat pivotul in dreapta
    for(int j=low; j<high; j++)
    {
        if(arr[j]<=pivot)
        {
            i++;
            inversare(&arr[i], &arr[j]);
        }
    }
    inversare(&arr[i+1],&arr[high]);
    return(i+1);
}
void quickSort(int arr[], int low, int high)
{
    if(low<high)
    {
        // selectam pozitia pivotului si punem toate elementele mai mici decat pivotul la stanga si mai mari decat pivotul la dreapta
        int pi=partitie(arr,low,high);
        // sortam elementele din stanga pivotului
        quickSort(arr, low, pi - 1);
        // sortam elementele din dreeapta pivotului
        quickSort(arr, pi + 1, high);
    }
}
void insertionSort(int arr[], int n)
{
    int i, j, k;
    for(i=1; i<n; i++)
    {
        k=arr[i];
        j=i-1;
        // comparam cheia cu fiecare element din stanga acestuia pana cand se gaseste un element mai mic decat este
        // pentru ordinea descrescatoare, schimbam k<sirul[j] la k>sirul[j]
        while(k<arr[j] && j>=0)
        {
            arr[j+1]=arr[j];
            --j;
        }
        arr[j+1]=k;
    }
}
// cautarea binara
void shellSort(int arr[], int n)
{
    int i, j, k=0;
    // rearanjam elementele la fiecare interval n/2, n/4, n/8,...,1  intervale
    for(i=n/2; i>0; i/=2)
    {
        for(j=i; j<n; j+=1)
        {
            k=arr[j];
            int z;
            for(z=j; z>=i && arr[z-i]>k; z-=i)
            {
                arr[z]=arr[z-i];
            }
            arr[z]=k;
        }
    }
}
int cautarea_binara(int arr[], int d, int low, int high)
{
    int mid;
	// repetam pana cand indicatoarele low si high se intalnesc
    while(low<=high)
    {
        mid=low+(high-low)/2;
        if(arr[mid]==d)
            return mid;
        if(arr[mid]<d)
            low=mid+1;
        else
            high=mid-1;
    }
    return -1;
}
// maximul unui sir de numere (recursiv)
int maxim(int v[10], int st, int dr)
{
    int i, m, m1, m2;
    for (i=st; i<=dr; i++)
        cout<<v[i]<<" ";
    cout<<endl;
    if (st==dr)
        return v[st];
    m=(st+dr)/2;
    m1=maxim(v,st,m);
    m2=maxim(v,m+1,dr);
    if (m1>=m2)
    {
        cout<<m1<<endl;
        return m1; // combina (divide et timpera)
    }
    else
    {
        cout<<m2<<endl;
        return m2;
    }
}
// minimul unui sir de numere (recursiv)
int minim(int v[10], int st, int dr)
{
    int i, m, m1, m2;
    for (i=st; i<=dr; i++)
        cout<<v[i]<<" ";
    cout<<endl;
    if (st==dr)
        return v[st];
    m=(st+dr)/2;
    m1=minim(v,st,m);
    m2=minim(v,m+1,dr);
    if (m1<=m2)
    {
        cout<<m1<<endl;
        return m1; // combina (divide et timpera)
    }
    else
    {
        cout<<m2<<endl;
        return m2;
    }
}
// plata unei sume s daca avem numar limitat de bacnote
void mod_de_plata(int s, int v[10], int n)
{
    int sc=s, i;
    int N[10], T=0;
    for (i=1; i<=n; i++)
    {
        N[i]=sc/v[i];
        sc=sc%v[i];
        T=T+N[i]*v[i];
    }
    if (s==T)
    {
        cout<<s<<"= ";
        for (i=1; i<=n; i++)
        {
            cout<<N[i]<<"*"<<v[i];
            if (i<n)
                cout<<"+";
        }
    }
    else
        cout<<"Algoritmul Greedy nu a gasit o solutie pentru problema data";
}
// turnurile din Hanoi
void hanoi(int n, char a, char b, char c)
{
    if(n==1)
        cout<<a<<b<<endl;
    else
    {
        hanoi(n-1,a,c,b);
        cout<<a<<b<<endl;
        hanoi(n-1,c,b,a);
    }
}
// produs de matrice cu numar minim de inmultiri
void paranteze(int i,int j,int M[20][20])
{
    int k;
    if(i<j)
    {
        k=M[j][i];
        if(i!=k)
        {
            cout<<"(";
            paranteze(i,k,M);
            cout<<")";
        }
        else
            paranteze(i,k,M);
        cout<<"*";
        if(k+1!=j)
        {
            cout<<"(";
            paranteze(k+1,j,M);
            cout<<")";
        }
        else
            paranteze(k+1,j,M);
    }
    else
        cout<<"A"<<i;
}
int produs_matrice(int n, int p[20])
{
    int M[20][20]={0};
    int minim, k0, v, i, j;
    cout<<"In procedura produs de matrice avem: ";
    cout<<n<<endl;
    for (i=1; i<=n+1; i++)
        cout<<p[i]<<" ";
    cout<<endl;
    for (i=n-1; i>=1; i--)
       for (j=i+1; j<=n; j++)
        {
            minim=M[i][i]+M[i+1][j]+p[i]*p[i+1]*p[j+1];
            k0=i;
            for(int k=i; k<=j-1; k++)
            {
                v=M[i][k]+M[k+1][j]+p[i]*p[k+1]*p[j+1];
                if(v<minim)
                {
                    minim=v;
                    k0=k;
                }
            }
            M[i][j]=minim;
            M[j][i]=k0;
        }
    cout<<"Matricea M este: "<<endl;
    for (i=1; i<=n; i++)
    {
        for (j=1; j<=n; j++)
           cout<<M[i][j]<<" ";
        cout<<endl;
    }
    paranteze(1,n,M);
    return M[1][n];
}
// suma maxima in triunghiul de numere
int suma_triunghi(int n, int A[10][10])
{
    int i, j;
    int S[10][10]={0}, D[10][10]={0}; // initializarea unei matrici cu 0
    for (j=0; j<n; j++)
        S[n-1][j]=A[n-1][j];
    for (i=n-2; i>=0; i--)
        // calculeaza linia i din S si din D
        for (j=0; j<=i; j++)
        {
            S[i][j]=A[i][j];
            if (S[i+1][j]>=S[i+1][j+1])
            {
                S[i][j]=S[i][j]+S[i+1][j];
                D[i][j]=j;
            }
            else
            {
                S[i][j]=S[i][j]+S[i+1][j+1];
                D[i][j]=j+1;
            }
        }
    cout<<"Matricea S este: ";
    for (i=0; i<n; i++)
    {
        for (j=0; j<=i; j++)
            cout<<S[i][j]<<" ";
        cout<<endl;
    }
    cout<<"Matricea D este: ";
    for (i=0; i<n; i++)
    {
        for (j=0; j<=i; j++)
            cout<<D[i][j]<<" ";
        cout<<endl;
    }
    cout<<"Suma maxima este: "<<S[0][0]<<endl;
    cout<<"Drumul este (0,0): ";
    for (i=1; i<n; i++)
        cout<<"("<<i<<","<<D[i-1][0]<<") ";
    cout<<endl;
    return S[0][0];
}
// verificare compunere sir intr-un alfabet dat
void paranteze_compunere(int i, int j, int B[30][30][20], int s, int A[30][30][20], int m)
{
    int k, c, c1, c2;
    if (i<j)
    {
        k=B[i][j][s];
        for (c=1; c<=m; c++)
        {
            if (A[i][k][c]==1)
                c1=c;
            if (A[k+1][j][c]==1)
                c2=c;
        }
        if (i!=k)
        {
            cout<<"(";
            paranteze_compunere(i,k,B,c1,A,m);
            cout<<")";
        }
        else
            paranteze_compunere(i,k,B,c1,A,m);
        cout<<"*";
        if (k+1!=j)
        {
            cout<<"(";
            paranteze_compunere(k+1,j,B,c2,A,m);
            cout<<")";
        }
        else
            paranteze_compunere(k+1,j,B,c2,A,m);
    }
    else
        cout<<"X"<<i;
}
int compunerea_alfabet(int m, int C[20][20], int n, int v[30], int s)
{
    int A[30][30][20]={0}, B[30][30][20]={0};
    int i, j, c, c1, c2, cdiag, ok=0;
    // initializare matricea A
    for (i=1; i<=n; i++)
        for (c=1; c<=m; c++)
            if (v[i]==c)
            {
                A[i][i][c]=1;
                B[i][i][c]=i;
            }
    // completam A pe codiagonala
    for (cdiag=1; cdiag<=n-1; cdiag++)
        for (i=1; i<=n-cdiag; i++)
        {
            j=i+cdiag;
            // calculam A[i][j][c] de la 1 la m
            for (c=1; c<=m; c++)
                for (k=i; k<=j-1; k++)
                    for (c1=1; c1<=m; c1++)
                        for (c2=1; c2<=m; c++)
                            if (A[i][k][c1]==1 && A[k+1][j][c2]==1 && C[c1][c2]==c)
                            {
                                A[i][j][c]=1;
                                B[i][j][c]=k;
                            }
        }
    cout<<A[1][n][s]<<endl;
    cout<<"Matricea A este: "<<endl;
    for (c=1; c<=m; c++)
    {
        cout<<"c= "<<c<<endl;
        for (i=1; i<=n; i++)
        {
            for (j=1; j<=n; j++)
                cout<<A[i][j][c]<<" ";
            cout<<endl;
        }
    }
    if (A[1][n][s]==1)
    {
        ok=1; // daca exista compunere
        paranteze_compunere(1,n,B,s,A,m);
        cout<<endl;
    }
    else
        ok=0; // daca nu exista compunere
    return ok;
}
// acul lui Buffon
void buffon()
{
    int n, ni_max=0, ni=0, ni_b=0, i;
    float p, eps, eroare, xa, xb, ya, yb, t;
    cout<<"Numarul de drepte n= ";
    cin>>n;
    cout<<"Dreptele pornesc de la p= ";
    cin>>p;
    cout<<"Numarul maxim de incercari ni_max= ";
    cin>>ni_max;
    cout<<"Eroare tolerata eps= ";
    cin>>eps;
    eroare=2*eps;
    while ((eroare>eps) && (ni<=ni_max))
    {
        do{
            xa=float(rand());
            xb=float(rand());
        }while((0.25-(xb-xa)*(xb-xa))<0);
        ya=float(rand());
        ni++;
        yb=ya+sqrt(0.25-(xb-xa)*(xb-xa));
        // alegem doar una dintre valori
        // verificam daca exista t in [0,1] astfek incat y=t(yb-ya)+ya este egal cu
        // cu yi=p+i-1 pentrju i=1,n
        for (i=1; i<=n; i++)
        {
            if (yb!=ya)
            {
                t=((p+i-1)-ya)/(yb-ya);
                if (t>=0 && t<=1)
                {
                    ni_b++; // acul intersecteaza dreapta di
                    break;
                }
            }
            else // yb=ya, acul este paralel cu dreptele
                if (ya==p+i-1)
                {
                    ni_b++; // acul se suprapune peste una dintre drepte
                    break;
                }
        }
        eroare=abs(ni_b/ni-1/pi);
    } // end while
    cout<<"Aproximarea lui pi este "<<float(ni/ni_b);
}
int main()
{
    // variabile ale main-ului
    int op, op1, op2, op3, op4, op5, op6, op7, op8;
    int n, m=0, i, j, s, x, nex, d, rezultat, pm, ok, k, l;
    int v[30], y[100], M[10][10], C[20][20], st[20];
    float A[10][10], ninf, n1;
    long long mm,nn;
    // main
    // do
    cout<<"PROGRAME TEORIA ALGORITMILOR - 2021"<<endl<<endl;
    cout<<"Budeci Ana-Maria, 1331a"<<endl;
    cout<<"________________________________"<<endl<<endl;
    do{
        cout<<endl<<"MENIU PRINCIPAL"<<endl<<"________________________________"<<endl;
        cout<<"PROGRAME TEORIA ALGORITMILOR"<<endl;
        cout<<"1. Exemple de algoritmi"<<endl;
        cout<<"2. Metode backtracking"<<endl;
        cout<<"3. Recursitate"<<endl;
        cout<<"4. Divide et Impera"<<endl;
        cout<<"5. Metoda Greedy"<<endl;
        cout<<"6. Programare dinamica"<<endl;
        cout<<"7. Metoda Branch and Bound"<<endl;
        cout<<"8. Metode probaliste (algoritmi probalisti)"<<endl;
        cout<<"0. Incheiere program"<<endl<<endl;
        cout<<"Optiune meniu principal op= ";
        cin>>op;
        switch(op){
            case 1:
                do{
                    cout<<endl<<"1. EXEMPLE DE ALGORITMI"<<endl<<endl;
                    cout<<"1.1. Norme de matrice"<<endl;
                    cout<<"1.2. Metoda coardei pentru ecuatii in multimea numerelor reale"<<endl;
                    cout<<"1.3. Metoda tangentei"<<endl;
                    cout<<"1.0. Iesire din meniu 1. EXEMPLE DE ALGORITMI"<<endl;
                    cout<<"Optiune pentru meniu 1, op1= ";
                    cin>>op1;
                    switch(op1){
                        case 1: // norme de matrice
                            // citim dimensiunea matricei
                            cout<<"Introduceti dimensiunea matricei: ";
                            cin>>m;
                            // citim matricea a
                            for (i=0; i<m; i++)
                                for (j=0; j<m; j++)
                                {
                                   cout<<"A["<<i<<"]["<<j<<"]=";
                                   cin>>A[i][j];
                                }
                            cout<<"Matricea a este: ";
                            for (i=0; i<m; i++)
                            {
                                for (j=0; j<m; j++)
                                    cout<<A[i][j]<<" ";
                                cout<<endl;
                            }
                            ninf=norma_infinit(m,A);
                            cout<<"Norma infinit a matricei A este: "<<ninf<<endl;
                            n1=norma1(m,A);
                            cout<<"Norma 1 a matricei A este: "<<n1<<endl;
                            break;
                        case 2:// metoda coardei pentru ecuatii in multimea numerelor reale
                            // aplicam metoda coardei pentru rezolvarea unei ecuatii f(x)=0 in R
                            metoda_coardei();
                            break;
                        case 3: // metoda tangentei
                            metoda_tangentei();
                            break;
                        case 0:
                            cout<<"Inchidere submeniului 1. EXEMPLE DE ALGORITMI"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op1!=0); // end switch op1
                break;
            case 2:
                do{
                    cout<<endl<<"2. METODE BACKTRACKING"<<endl<<endl;
                    cout<<"2.1. Generarea permutarilor"<<endl;
                    cout<<"2.2. Generarea combinarilor"<<endl;
                    cout<<"2.3. Generarea aranjamentelor"<<endl;
                    cout<<"2.4. Problema reginelor"<<endl;
                    cout<<"2.5. Problema turelor"<<endl;
                    cout<<"2.6. Problema calutilor"<<endl;
                    cout<<"2.7. Problema comisului voiajor"<<endl;
                    cout<<"2.8. Problema parantezelor"<<endl;
                    cout<<"2.0. Iesire din meniu 2. METODE BACKTRACKING"<<endl;
                    cout<<"Optiune pentru meniu 2, op2= ";
                    cin>>op2;
                    switch(op2){
                        case 1: // generarea permutarilor
                            cout<<"Generarea permutarilor n= ";
                            cin>>na;
                            bkt1();
                            afisare1();
                            break;
                        case 2: // generarea combinarilor
                            cout<<"Generarea combinarilor n= ";
                            cin>>na;
                            cout<<" luate cate p= ";
                            cin>>p;
                            bkt2();
                            break;
                        case 3: // generarea aranjamentelor
                            cout<<"Generarea aranjamentelor n= ";
                            cin>>na;
                            cout<<" luate cate p= ";
                            cin>>p;
                            bkt3();
                            break;
                        case 4: // problema reginelor
                            problema_reginelor();
                            break;
                        case 5: // problema turelor
                            cout<<"Problema turelor"<<endl;
                            cout<<"Numar ture: ";
                            cin>>n;
                            generareTure(n);
                            break;
                        case 6: // problema calutilor
                            cout<<"Problema calutilor "<<endl;
                            cout<<"Numar caluti: ";
                            cin>>n;
                            generareCaluti(n);
                            break;
                        case 7: // problema comisului voiajor
                            break;
                        case 8: // problema parantezelor
                            numar *sp;
                            char expresie[200]; // presupunem ca expresia nu are spatii
                            cout<<"Expresia este: ";
                            cin>>expresie;
                            nex=strlen(expresie);
                            cout<<"Lungimea expresiei= "<<nex<<endl<<expresie<<endl;
                            // se scriu parantezele intr-o stiva de numere intregi
                            sp=new numar;
                            sp=NULL;
                            for (i=0; i<nex; i++)
                            {
                                bool ok=true; // true daca expresia e corecta
                                switch(expresie[i]){
                                    case '{':
                                        cout<<"A gasit {"<<endl;
                                        // scrie 1 in stiva
                                        if(sp) // stiva nu este vida, adauga in stiva
                                            sp=adaugare_element_in_stiva(sp,1);
                                        else
                                            sp=initializare_stiva(1);
                                        parcurgere_stiva(sp);
                                        break;
                                    case '[':
                                        cout<<"A gasit ["<<endl;
                                        // scrie 2 in stiva
                                        if(sp) // stiva nu este vida, adauga in stiva
                                            sp=adaugare_element_in_stiva(sp,2);
                                        else
                                            sp=initializare_stiva(2);
                                        parcurgere_stiva(sp);
                                        break;
                                    case '(':
                                        cout<<"A gasit ("<<endl;
                                        // scrie 3 in stiva
                                        if(sp) // stiva nu este vida, adauga in stiva
                                            sp=adaugare_element_in_stiva(sp,3);
                                        else
                                            sp=initializare_stiva(3);
                                        parcurgere_stiva(sp);
                                        break;
                                    case ')':
                                        // verifica daca primul element in stiva este 3 si il sterge, altfel este expresia gresita=>ok=false
                                        if(sp->v==3)
                                            sp=stergere_din_stiva(sp);
                                        else
                                            ok=false;
                                        break;
                                    case ']':
                                        // verifica daca primul element in stiva este 2 si il sterge, altfel este expresia gresita=>ok=false
                                        if(sp->v==2)
                                            sp=stergere_din_stiva(sp);
                                        else
                                            ok=false;
                                        break;
                                    case '}':
                                        // verifica daca primul element in stiva este 1 si il sterge, altfel este expresia gresita=>ok=false
                                        if(sp->v==1)
                                            sp=stergere_din_stiva(sp);
                                        else
                                            ok=false;
                                        break;
                                    default:
                                        break;
                                } // end switch
                                if(!ok)
                                {
                                    cout<<"Expresie gresita! Parantezele nu se potrivesc.";
                                    break;
                                }
                            }
                            cout<<endl;
                            parcurgere_stiva(sp);
                            // daca stiva este vida si ok==true atunci expresia este corecta, altfel nu este corecta
                            if(sp)
                                cout<<"Stiva nu este vida: sunt paranteze deschise care nu au pereche!"<<endl;
                            else
                                cout<<"Expresia este corecta!"<<endl;
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 2. METODE BACKTRACKING"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op2!=0); // end switch op2
                break;
            case 3:
                do{
                    cout<<endl<<"3. RECURSIVITATE"<<endl<<endl;
                    cout<<"3.1. Factorialul"<<endl;
                    cout<<"3.2. Sirul Fibonacci"<<endl;
                    cout<<"3.3. Functia Ackerman (recursiva)"<<endl;
                    cout<<"3.4. Functia Ackerman (iterativa)"<<endl;
                    cout<<"3.5. Problema labirintului"<<endl;
                    cout<<"3.6. Backtracking recursiv"<<endl;
                    cout<<"3.7. Descompunere in factori primi (recursiv)"<<endl;
                    cout<<"3.8. Trecerea din baza 10 in baza b de la 2 la 9"<<endl;
                    cout<<"3.9. Numarul de partitii ale unei multimi"<<endl;
                    cout<<"3.10. Recursivitate indirecta: miscarea unui punct pe ecran"<<endl;
                    cout<<"3.0. Iesire din meniu 3. RECURSIVITATE"<<endl;
                    cout<<"Optiune pentru meniu 3, op3= ";
                    cin>>op3;
                    switch(op3){
                        case 1: // factorialul
                            cout<<"Introduceti numarul caruia doriti sa aflati factorialul: ";
                            cin>>x;
                            n=factorial(x);
                            cout<<"Factorialul numarului este: "<<n;
                            return 0;
                            break;
                        case 2: // sirul Fibonacci
                            cout<<"Sirul fibonacii pentru n=";
                            cin>>n;
                            cout<<" este: "<<fibonacci(n)<<endl;
                            break;
                        case 3: // functia Ackerman (recursiva)
                            cout<<"Introduceti prima cifra: ";
                            cin>>mm;
                            cout<<"Introduceti al doilea numar: ";
                            cin>>nn;
                            cout<<ack(mm,nn);
                            break;
                        case 4: // functia Ackerman (iterativa)
                            cout<<"Funcita Ackermann(iterativa)"<<endl;
                            cout<<"k=";
                            cin>>k;
                            ackermannIterativ(k);
                            break;
                        case 5: // problema labirintului
                            break;
                        case 6: // backtracking recursiv
                            cout<<"Backtracking Recursiv"<<endl;
                            cout<<"Problema permutarillor"<<endl;
                            cout<<"n=";
                            cin>>n;
                            backT(st,1,n);
                            break;
                        case 7: // descompunere in factori primi (recursiv)
                            cout<<"Introduceti numarul pe care doriti sa il descompuneti: ";
                            cin>>n;
                            factori_primi(n);
                            break;
                        case 8: // trecerea din baza 10 in baza b de la 2 la 9
                            cout<<"Introduceti numarul n in baza 10: ";
                            cin>>n;
                            cout<<"Introduceti baza in care doriti sa il schimbati: ";
                            cin>>i;
                            schimbare_baza(n,i);
                            break;
                        case 9: // numarul de partitii ale unei multimi
                            cout<<"Numarul de partitii ale unei multimi"<<endl;
                            cout<<"n=";
                            cin>>n;
                            cout<<"k=";
                            cin>>k;
                            cout<<partitie(n,k)<<endl;
                            break;
                        case 10: // recursivitate indirecta: miscarea unui punct pe ecran
                            cout<<"Recursivitate indirecta"<<endl;
                            cout<<"l=";
                            cin>>l;
                            cout<<"n=";
                            cin>>n;
                            urcare(l,n);
                            cout<<endl;
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 3. RECURSIVITATE"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op3!=0); // end switch op3
                break;
            case 4:
                do{
                    cout<<endl<<"4. DIVIDE ET IMPERA"<<endl<<endl;
                    cout<<"4.1. Sortarea prin interclasare (merge sort)"<<endl;
                    cout<<"4.2. Sortarea rapida (quick sort)"<<endl;
                    cout<<"4.3. Cautarea binara"<<endl;
                    cout<<"4.4. Maximul unui sir de numere (recursiv)"<<endl;
                    cout<<"4.5. Minimul unui sir de numere (recursiv)"<<endl;
                    cout<<"4.6. Turnurile din Hanoi"<<endl;
                    cout<<"4.0. Iesire din meniu 4. DIVIDE ET IMPERA"<<endl;
                    cout<<"Optiune pentru meniu 4, op4= ";
                    cin>>op4;
                    switch(op4){
                        case 1: // sortarea prin interclasare (merge sort)
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            mergeSort(y,0,n-1);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 2: // sortarea rapida (quick sort)
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            quickSort(y,0,n-1);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            break;
                        case 3: // cautarea binara
                            cout<<"Dimensiune sir n= ";
                            cin>>n;
                            for(i=0; i<=n-1; i++)
                            {
                                cout<<"x["<<i<<"]= ";
                                cin>>y[i];
                            }
                            cout<<"Introduceti numarul cautat: ";
                            cin>>d;
                            shellSort(y,n);
                            cout<<"Sirul sortat este: ";
                            afisare(n,y);
                            rezultat=cautarea_binara(y,d,0,n-1);
                            if(rezultat==-1)
                                cout<<"Nu se gaseste";
                            else
                                cout<<"Elementul a fost gasit in sir";
                            break;
                        case 4: // maximul unui sir de numere (recursiv)
                            cout<<"Dimensiunea sirului este n= ";
                            cin>>n;
                            cout<<"Sirul este: ";
                            for (i=1; i<=n; i++)
                                cin>>v[i];
                            m=maxim(v,1,n);
                            cout<<"Maximul elementelor sirului este: "<<m<<endl;
                            break;
                        case 5: // minimul unui sir de numere (recursiv)
                            cout<<"Dimensiunea sirului este n= ";
                            cin>>n;
                            cout<<"Sirul este: ";
                            for (i=1; i<=n; i++)
                                cin>>v[i];
                            m=minim(v,1,n);
                            cout<<"Minimul elementelor sirului este: "<<m<<endl;
                            break;
                        case 6: // turnurile din Hanoi
                            cout<<"Turnurile din Hanoi"<<endl;
                            cout<<"n=";
                            cin>>n;
                            hanoi(n,'a','b','c');
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 4. DIVIDE ET IMPERA"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op4!=0); // end switch op4
                break;
            case 5:
                do{
                    cout<<endl<<"5. METODA GREEDY"<<endl<<endl;
                    cout<<"5.1. Problema comisului voiajor"<<endl;
                    cout<<"5.2. Plata unei sume s daca avem numar nelimitat de bacnote"<<endl;
                    cout<<"5.3. Plata unei sume s daca avem numar limitat de bacnote"<<endl;
                    cout<<"5.4. Acoperirea unei table de sah cu mutari calut"<<endl;
                    cout<<"5.0. Iesire din meniu 5. METODA GREEDY"<<endl;
                    cout<<"Optiune pentru meniu 5, op5= ";
                    cin>>op5;
                    switch(op5){
                        case 1: // problema comisului voiajor
                            break;
                        case 2: // plata unei sume s daca avem numar nelimitat de bacnote
                            cout<<"Numarul de tipuri de bacnote: ";
                            cin>>n;
                            cout<<"Valorile tipurilor de bacnote in ordine descrescatoare sunt: ";
                            for (i=1; i<=n; i++)
                                cin>>v[i];
                            cout<<"Suma de platit este: ";
                            cin>>s;
                            mod_de_plata(s,v,n);
                            cout<<endl;
                            break;
                        case 3: // plata unei sume s daca avem numar limitat de bacnote
                            break;
                        case 4: // acoperirea unei table de sah cu mutari calut
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 5. METODA GREEDY"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op5!=0); // end switch op5
                break;
            case 6:
                do{
                    cout<<endl<<"6. PROGRAMARE DINAMICA"<<endl<<endl;
                    cout<<"6.1. Produs de matrice cu numar minim de inmultiri"<<endl;
                    cout<<"6.2. Suma maxima in triunghiul de numere"<<endl;
                    cout<<"6.3. Verificare compunere sir intr-un alfabet dat"<<endl;
                    cout<<"6.0. Iesire din meniu 6. PROGRAMARE DINAMICA"<<endl;
                    cout<<"Optiune pentru meniu 6, op6= ";
                    cin>>op6;
                    switch(op6){
                        case 1: // produs de matrice cu numar minim de inmultiri
                            cout<<"Numarul de matrice: ";
                            cin>>n;
                            cout<<"Dimensiunile matricelor: ";
                            for(int i=1; i<=n+1; i++)
                                cin>>v[i];
                            pm=produs_matrice(n,v);
                            cout<<"Numarul minim de inmultiri este: "<<pm<<endl;
                            break;
                        case 2: // suma maxima in triunghiul de numere
                            cout<<"Citim numarul n= ";
                            cin>>n;
                            cout<<"Triunghiul de numere este: ";
                            for (i=0; i<n; i++)
                                for (j=0; j<=i; j++)
                                    cin>>M[i][j];
                            m=suma_triunghi(n,M);
                            cout<<"Suma maxima in triunghiul de numere este: "<<m<<endl;
                            break;
                        case 3: // verificare compunere sir intr-un alfabet dat
                            cout<<"Numarul de caractere din alfabet este m= ";
                            cin>>m;
                            cout<<"Matricea de compunere C din alfabet este: "<<endl;
                            for (i=1; i<=m; i++)
                                for (j= 1; j<=m; j++)
                                    cin>>C[i][j];
                            cout<<"Numarul de caractere din vectorul v este n= ";
                            cin>>n;
                            cout<<"Vectorul v este: ";
                            for (i=1; i<=n; i++)
                                cin>>v[i];
                            cout<<"Elementul din S este s= ";
                            cin>>s;
                            ok=compunerea_alfabet(m,C,n,v,s);
                            if (ok==1)
                                cout<<"Exista compunere a elementelor lui v astfel incat sa obtinem s"<<endl;
                            else
                                cout<<"Nu exista nicio compunere a elementelor lui v nu da s"<<endl;
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 6. PROGRAMARE DINAMICA"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op6!=0); // end switch op6
                break;
            case 7:
                do{
                    cout<<endl<<"7. METODA BRANCH AND BOUND"<<endl<<endl;
                    cout<<"7.1. Jocul Perspico"<<endl;
                    cout<<"7.0. Iesire din meniu 7. METODA BANCH AND BOUND"<<endl;
                    cout<<"Optiune pentru meniu 7, op7= ";
                    cin>>op7;
                    switch(op7){
                        case 1: // jocul Perspico
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 7. METODA BANCH AND BOUND"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op7!=0); // end switch op7
                break;
            case 8:
                do{
                    cout<<endl<<"8. METODE PROBALISTE (ALGORITMI PROBABILISTI)"<<endl<<endl;
                    cout<<"8.1. Acul lui Buffon"<<endl;
                    cout<<"8.2. Aruncare sageata"<<endl;
                    cout<<"8.3. Aproximare integrala"<<endl;
                    cout<<"8.4. Gasirea unui element mai mare decat media artimetica"<<endl;
                    cout<<"8.5. Eliminarea modurilor unui graf prin numar minim de mutari"<<endl;
                    cout<<"8.6. Gasirea unui test comun (intr-un sir de texte)"<<endl;
                    cout<<"8.7. Algoritmul probabilist pentru problema celor n regine"<<endl;
                    cout<<"8.0. Iesire din meniu 8. METODE PROBALISTE (ALGORITMI PROBABILISTI)"<<endl;
                    cout<<"Optiune pentru meniu 8, op8= ";
                    cin>>op8;
                    switch(op8){
                        case 1: // acul lui Buffon
                            cout<<"Acul lui Buffon"<<endl;
                            buffon();
                            break;
                        case 2: // aruncare sageata
                            break;
                        case 3: // aproximare integrala
                            break;
                        case 4: // gasirea unui element mai mare decat media artimetica
                            break;
                        case 5: // eliminarea modurilor unui graf prin numar minim de mutari
                            break;
                        case 6: // gasirea unui test comun (intr-un sir de texte)
                            break;
                        case 7: // algoritmul probabilist pentru problema celor n regine
                            break;
                        case 0:
                            cout<<"Inchidere submeniu 8. METODE PROBALISTE (ALGORITMI PROBABILISTI)"<<endl;
                            break;
                        default:
                            cout<<"Optiune invalida!"<<endl;
                            break;
                    }
                }while(op8!=0); // end switch op8
                break;
            case 0:
                cout<<"Inchidere program"<<endl;
                break;
            default:
                cout<<"Optiune invalida!"<<endl;
                break;
        } // end switch op
    }while(op);
    return 0;
}
